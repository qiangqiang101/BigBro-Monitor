<?php

	function _hash($str) {
		return hash("md5", $str);
	}
	
?>